# APFinder Contenu 
Un script pour detecter la page de login admin d'un site web. 

how to use ? / Comment l'utiliser ?

python 3 obligatoire

cd APFinder
python3 APFinder.py -u (ne pas mettre le https:// juste le nom du site avec son domaine (.com , .fr etccc))
Exemple python3 APFinder.py -u google.com et non python3 APFinder.py -u https://google.com
